
function appointmentAccept(){
    //change the id name hello accordingly what you declared in html
    document.getElementById('hello').innerHTML="Your appointment is booked at this timeslot "
}
function appointmentReject(){
    //change the id name hello accordingly what you declared in html
    document.getElementById('hello').innerHTML="Your appointment is Rejected choose another time"
}