 const express=require('express')
const { email } = require('is')
const database = require('mime-db')
 const mysql=require('mysql')
 const path=require('path')
 const port=8080
 const app=express()
 let con=mysql.createConnection({
     host:"localhost",
     user:"root",
     password:"",
     database:"dbs_task"
 })
 con.connect((err)=>{
    if(err){
        console.log('please enter valid username and password')
    }else{
        console.log("DB connection Established")
    } 
})
//mention the sign in path here
app.get('/signin',(req,res)=>{
    res.sendFile(path.join(__dirname,''))
})
app.post('/hnisignin',(err,res)=>{
    con.query('select username,password from hni_user',(err,result)=>{
        let users=[]
        let passwords=[]
        users.push(result[0].email)
        passwords.push(result[0].password)
        email=req.body.user_name
        pass=req.body.password
        if(users.includes(email) && passwords.includes(pass) ){
            //insert the hni dashboard src here
            res.send(path.join(__dirname,''))
        }
        else{
            res.send("incorrect credentials")
        }
    })
})
app.post('/wmsignin',(err,res)=>{
    con.query('select username,password from wm_user',(err,result)=>{
        let users=[]
        let passwords=[]
        users.push(result[0].email)
        passwords.push(result[0].password)
        email=req.body.user_name
        pass=req.body.password
        if(users.includes(email) && passwords.includes(pass) ){
            //insert the wm dashboard src here
            res.send(path.join(__dirname,''))
        }
        else{
            res.send("incorrect credentials")
        }
    })
})
 app.get('/hnidetails',(req,res)=>{
     con.query('select * from hni_details where availability=available',(err,result)=>{
         let hnis=[]
         hnis.push(result)
        con.query('select slot_time from time_slots where availability=available',(err,result)=>{
         hnis.push(result)
         res.send(hnis)
     })
    })
 })
 /*app.get('/wmdetails',(req,res)=>{
   con.query('select * from wm_details',(err))  
 })*/
 app.post('/wmregister',(req,res)=>{
     con.query('insert into wm_user(user_name,email,password)values(?,?,?)',[req.body.user_name,req.body.email,req.body.password],(err,result)=>{
         res.send('User Registered')
     })
 })
 app.post('/hniregister',(req,res)=>{
    con.query('insert into hni_user(user_name,email,password)values(?,?,?)',[req.body.user_name,req.body.email,req.body.password],(err,result)=>{
        res.send('User Registered')
    })
})
 
 
 app.listen(port,(err)=>{
     if(err){
         console.log(`ERROR in establishing connection`)
     }
     else{
         console.log(`Listening at http://localhost:${port}/`)
     }
 })

